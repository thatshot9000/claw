* Claw machine widget made for this project: https://youtu.be/qzxGPNiFiFI?si=OmrP1dVBJK5-IXxR
* You can find a tutorial for how to use this project here: https://www.answerinprogress.com/claw-machine-tutorial
* You can find an example of this page with the default settings here: https://aipwidgets.click/claw-machine-widget/game.html
* You can find another example of this widget embedded into a web page here: https://braindumpclawmachine.com/
